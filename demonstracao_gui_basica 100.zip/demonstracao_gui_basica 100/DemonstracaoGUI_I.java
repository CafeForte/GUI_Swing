package demonstracao_gui_basica;

import java.awt.HeadlessException;

public class DemonstracaoGUI_I
   {
   public static void main(String[] args)
      {
      try
         {
         JanelaPrincipal programa = new JanelaPrincipal();
         programa.inicia();
         }
      catch (HeadlessException excecao)
         {
         imprMsgErroETermina("Programa terminado por uma HeadlessException no método main()", excecao);
         }
      catch (Exception excecao)
         {
         imprMsgErroETermina("Programa terminado por uma Generic Exception no método main()", excecao);
         }
      }

   private static void imprMsgErroETermina(String mensagem, Exception ocorrencia)
      {
      System.out.println("Mensagem de erro:\t" + mensagem);
      System.out.println("Texto da exceção:\t" + ocorrencia.getMessage());
      System.exit(1);
      }
   }
