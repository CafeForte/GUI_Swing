package demonstracao_gui_basica;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.Random;

import javax.swing.JPanel;

/**
 * This class is the drawing screen of the system
 * 
 * @author <b>Andre Franceschi de Angelis</b> - <i>Unicamp</i> - Aug 21, 2015
 *         <p>
 * @version 1.0
 * @since 1.0
 */
class PainelFundo extends JPanel
   {
   private static final long serialVersionUID = 1L;
   private Color             lineColor        = Color.red;
   private Point             attractors[]     = new Point[2];

   /**
    * Default constructor
    */
   PainelFundo()
      {
      super();
      this.setBackground(Color.lightGray);
      }

   /**
    * Recreates the screen after a change in it
    * 
    * @see javax.swing.JComponent#paint(java.awt.Graphics)
    */
   @Override
   public void paint(Graphics canvasOriginal)
      {
      super.paint(canvasOriginal);

      Graphics2D canvas = (Graphics2D) canvasOriginal;
      Random rand = new Random();

      int maxX = this.getWidth();
      int maxY = this.getHeight();
      canvas.setColor(this.lineColor);

      int limit = rand.nextInt(200);

      for (int howMany = 0; howMany < limit; howMany++)
         {
         canvas.drawLine(rand.nextInt(maxX), rand.nextInt(maxY), rand.nextInt(maxX), rand.nextInt(maxY));
         if (attractors[0] != null)
            {
            canvas.drawLine((int) attractors[0].getX(), (int) attractors[0].getY(), rand.nextInt(maxX),
                            rand.nextInt(maxY));
            }
         if (attractors[1] != null)
            {
            canvas.drawLine((int) attractors[1].getX(), (int) attractors[1].getY(), rand.nextInt(maxX),
                            rand.nextInt(maxY));
            }
         }
      }

   /**
    * @param lineColor the lineColor to set
    */
   void setLineColor(Color lineColor)
      {
      this.lineColor = lineColor;
      }

   public void setNewAttractor(Point point)
      {
      attractors[0] = attractors[1];
      attractors[1] = point;
      }

   }
