package demonstracao_gui_basica;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

class PainelFundo extends JPanel
   {
   private static final long serialVersionUID = 1L;
   private Color             corFrente        = Color.white;
   private Color             corFundo         = Color.lightGray;

   PainelFundo()
      {
      super();
      this.setForeground(corFrente);
      this.setBackground(corFundo);
      }

   @Override
   public void paint(Graphics canvasOriginal)
      {
      super.paint(canvasOriginal);
      Graphics2D canvas = (Graphics2D) canvasOriginal;

      setForeground(corFrente);
      setBackground(corFundo);

      int maxX = this.getWidth();
      int maxY = this.getHeight();

      canvas.drawString("Tamanho do canvas: " + maxX + " x " + maxY, 20, 20);
      }

   void setCorFrente(Color novaCor)
      {
      this.corFrente = novaCor;
      }

   void setCorFundo(Color novaCor)
      {
      this.corFundo = novaCor;
      }

   }
