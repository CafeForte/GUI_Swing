package demonstracao_gui_basica;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;

import javax.swing.JPanel;

class PainelFundo extends JPanel
   {
   private static final long serialVersionUID = 1L;
   private Color             corFrente        = Color.white;
   private Color             corFundo         = Color.lightGray;
   private Random            rand             = new Random();

   PainelFundo()
      {
      super();
      this.setForeground(corFrente);
      this.setBackground(corFundo);
      }

   @Override
   public void paint(Graphics canvasOriginal)
      {
      super.paint(canvasOriginal);
      Graphics2D canvas = (Graphics2D) canvasOriginal;

      setForeground(corFrente);
      setBackground(corFundo);

      int maxX = this.getWidth();
      int maxY = this.getHeight();

      int limit = rand.nextInt(200);

      for (int howMany = 0; howMany < limit; howMany++)
         {
         canvas.drawLine(rand.nextInt(maxX), rand.nextInt(maxY), rand.nextInt(maxX), rand.nextInt(maxY));
         }
      }

   void setCorFrente(Color novaCor)
      {
      this.corFrente = novaCor;
      }

   void setCorFundo(Color novaCor)
      {
      this.corFundo = novaCor;
      }
   }
