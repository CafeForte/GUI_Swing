package demonstracao_gui_basica;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

class OuvinteDeMouse implements MouseListener
   {
   private PainelFundo referencia;

   OuvinteDeMouse(PainelFundo referencia)
      {
      super();
      this.referencia = referencia;
      }

   @Override
   public void mouseClicked(MouseEvent mouseEvent)
      {
      referencia.setNewAttractor(mouseEvent.getPoint());
      referencia.repaint();
      }

   @Override
   public void mouseEntered(MouseEvent arg0)
      {
      // TODO Auto-generated method stub
      }

   @Override
   public void mouseExited(MouseEvent arg0)
      {
      // TODO Auto-generated method stub
      }

   @Override
   public void mousePressed(MouseEvent arg0)
      {
      // TODO Auto-generated method stub
      }

   @Override
   public void mouseReleased(MouseEvent arg0)
      {
      // TODO Auto-generated method stub
      }

   }
